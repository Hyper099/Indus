import MainContent from './FrontEndComponents/MainContent';
import './styles/App.css';

function App() {
   return (
      <div>
         <MainContent />
      </div>
   );
}

export default App;
