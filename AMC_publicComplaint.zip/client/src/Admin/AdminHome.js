function AdminHome(){
    return(
        <div>
            <h1>this is home page of admin</h1>
        </div>
    )
}
export default AdminHome;